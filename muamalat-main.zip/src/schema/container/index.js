import LoadAll from './LoadAll';
import LoadOne from './LoadOne';

export {
  LoadAll,
  LoadOne
}