import {all, call, put, takeLatest} from 'redux-saga/effects';
import Actions from '../actions';
import {api} from 'services';
import {session} from 'services';
import get from 'lodash.get';

function* Login(action) {
  const {
    url,
    values,
    cb
  } = action.payload;
  try {
    const {data: {result}} = yield call(api.request.post, api.queryBuilder(url, {}), {...values});
    
    yield put(Actions.LOGIN.success(result));
    yield call(cb.success, result);
  } catch (err) {
    yield put(Actions.LOGIN.failure(get(err, 'response.data', '')));
    yield call(cb.error, get(err, 'response.data'));
    yield put(Actions.ERRORS.success({
      error: get(err, 'response', '')
    }));
  } finally {
    yield call(cb.finally)
  }
}

function* Logout({payload}) {
  const {cb, navigate} = payload;
  try {
    // Check if user is a customer (role_id: 3)
    const user = JSON.parse(session.get('user') || '{}');
    const refreshToken = session.get('refreshToken');
    
    if (user.role_id === 3 && refreshToken) {
      // Customer logout with refreshToken
      yield call(api.customerAuth.logout, {refreshToken});
    } else {
      // Regular admin/staff logout
      yield call(api.request.post, api.queryBuilder('/logout', {}));
    }
    
    yield put(Actions.LOGOUT.success());
    if (navigate) {
      navigate()
    }
    yield call(cb.success);
  } catch (err) {
    // Even if logout API returns 401, still clear session locally
    yield put(Actions.LOGOUT.success());
    if (navigate) {
      navigate()
    }
    yield call(cb.success);
  }
}

function* CustomerAuthStart(action) {
  const {phoneNumber, intent, firstName, lastName, cb} = action.payload;
  try {
    const payload = {phoneNumber, intent};
    if (intent === 'REGISTER') {
      payload.firstName = firstName;
      payload.lastName = lastName;
    }
    
    const response = yield call(api.customerAuth.start, payload);
    const txId = get(response, 'data.txId');
    
    yield put(Actions.CUSTOMER_AUTH_START.success({
      txId, 
      intent, 
      phoneNumber, 
      firstName, 
      lastName
    }));
    
    yield call(cb.success, {txId});
  } catch (err) {
    yield put(Actions.CUSTOMER_AUTH_START.failure(get(err, 'response.data', '')));
    yield call(cb.error, get(err, 'response.data'));
  }
}

function* CustomerAuthVerify(action) {
  const {txId, code, cb} = action.payload;
  try {
    const response = yield call(api.customerAuth.verify, {txId, code});
    
    if (response.status === 200) {
      // Get tokens using refresh endpoint
      const refreshResponse = yield call(api.customerAuth.refresh, {
        refreshToken: response.data?.refreshToken || 'temp_token'
      });
      
      const authData = get(refreshResponse, 'data');
      
      if (authData) {
        session.set('token', authData.accessToken);
        session.set('refreshToken', authData.refreshToken);
        session.set('user', JSON.stringify({
          id: authData.userId,
          identifier: authData.identifier,
          firstName: authData.firstName,
          lastName: authData.lastName,
          role_id: 3 // Customer role
        }));
        
        yield put(Actions.LOGIN.success({
          token: authData.accessToken,
          user: {
            id: authData.userId,
            identifier: authData.identifier,
            firstName: authData.firstName,
            lastName: authData.lastName,
            role_id: 3
          }
        }));
      }
      
      yield call(cb.success, authData);
    }
  } catch (err) {
    yield put(Actions.CUSTOMER_AUTH_VERIFY.failure(get(err, 'response.data', '')));
    yield call(cb.error, get(err, 'response.data'));
  }
}

function* CustomerAuthResend(action) {
  const {txId, cb} = action.payload;
  try {
    yield call(api.customerAuth.resend, {txId: txId});
    yield put(Actions.CUSTOMER_AUTH_RESEND.success());
    yield call(cb.success);
  } catch (err) {
    yield put(Actions.CUSTOMER_AUTH_RESEND.failure(get(err, 'response.data', '')));
    yield call(cb.error, get(err, 'response.data'));
  }
}

export default function* AuthSaga() {
  yield all([
    takeLatest(Actions.LOGIN.REQUEST, Login),
    takeLatest(Actions.LOGOUT.REQUEST, Logout),
    takeLatest(Actions.CUSTOMER_AUTH_START.REQUEST, CustomerAuthStart),
    takeLatest(Actions.CUSTOMER_AUTH_VERIFY.REQUEST, CustomerAuthVerify),
    takeLatest(Actions.CUSTOMER_AUTH_RESEND.REQUEST, CustomerAuthResend)
  ])
}