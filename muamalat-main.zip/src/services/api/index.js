import axios from 'axios';
import buildUrl from 'build-url';
import config from 'config';
import get from 'lodash.get';
import qs from 'qs';
import storage from '../storage';
import session from '../session';

const request = axios.create({
  baseURL: config.API_ROOT,
  // defaults: {
  headers: {
    common: {
      "Accept": "application/json",
      "Cache-Control": "no-cache",
      "Authorization": `Bearer ${session.get('token')}`,
      "Content-Type": "application/json",
      "X-Localization": storage.get("language") ? storage.get("language") : 'oz'
    },
  }
  // }
});
request.defaults.headers.common["Cache-Control"] = "no-cache";

const queryBuilder = (
  url = '',
  {
    limit,
    q = '',
    page,
    perPage,
    filter = {},
    search = {},
    search_extra = {},
    extra = {}
  } = {}
) => {
  
  let query = {};
  
  if (get(config, "API_KEY")) {
    query['key'] = get(config, "API_KEY")
  }
  
  if (limit > 0) {
    query['maxResults'] = limit;
  }
  if (perPage > 0) {
    query['per_page'] = perPage;
  }
  if (q) {
    query['q'] = q
  }
  
  if (page > 0) {
    query['page'] = page;
  }
  
  if (Object.keys(filter).length) {
    Object.keys(filter).forEach(item => {
      const normalized = qs.stringify({filter: {[item]: filter[item]}}, {encode: false}).split("&");
      normalized.forEach(item => {
        const splited = item.split("=");
        if (splited.length === 2 && splited[0] && splited[1]) {
          query[splited[0]] = splited[1];
        }
      });
    });
  }
  
  if (Object.keys(search).length || Object.keys(search_extra).length) {
    const NORMALIZED = Object.keys(search).map(item => {
      return qs.stringify({search: {[item]: search[item]}}, {encode: false}).split("&");
    }).flat(1);
    const EXTRA_NORMALIZED = Object.keys(search_extra).map(extra => {
      return qs.stringify({[extra]: search_extra[extra]}, {encode: false}).split("&");
    }).flat(1);
    const ALL_NORMALIZED = [...NORMALIZED, ...EXTRA_NORMALIZED]
    
    ALL_NORMALIZED.forEach(item => {
      const splited = item.split("=");
      if (splited.length === 2 && splited[0] && splited[1]) {
        query[splited[0]] = splited[1];
      }
    });
  }
  
  if (Object.keys(extra).length) {
    Object.keys(extra).forEach(key => {
      if (key && extra[key]) {
        query[key] = extra[key]
      }
    })
  }
  
  return buildUrl({
    path: url,
    queryParams: query
  })
};


const subscribe = store => {
  let token = session.get("token");
  
  let state = store.getState();
  
  if (state.auth.token) {
    token = get(state, "auth.token");
  }
  if (token) {
    request.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    request.defaults.headers.common["Cache-Control"] = "no-cache";
  }
};

// Customer auth endpoints using localhost:8080 (through proxy)
const customerAuthRequest = axios.create({
  baseURL: process.env.NODE_ENV === 'development' ? '' : 'http://localhost:8080',
  headers: {
    common: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization"
    }
  }
});

// Add response interceptor to handle CORS
customerAuthRequest.interceptors.response.use(
  response => response,
  error => {
    if (error.code === 'ERR_NETWORK') {
      console.error('CORS or network error. Make sure the backend server is running and has CORS enabled.');
    }
    return Promise.reject(error);
  }
);

const customerAuth = {
  start: (data) => customerAuthRequest.post('/auth/start', data),
  verify: (data) => customerAuthRequest.post('/auth/verify', data),
  resend: (data) => customerAuthRequest.post(`/auth/resend?txId=${data.txId}`),
  refresh: (data) => customerAuthRequest.post('/auth/refresh', data),
  logout: (data) => customerAuthRequest.post('/auth/logout', data)
};

const defaultExport = {
  request,
  queryBuilder,
  subscribe,
  customerAuth
};

export default defaultExport;